.. _ref_core_init:

===============
Boto3 Reference
===============

.. automodule:: boto3
   :members:
   :undoc-members:
